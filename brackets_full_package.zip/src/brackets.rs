use crate::stack::Stack;

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum BracketErrorKind {
    UnexpectedClosing { found: char },
    MismatchedPair    { expected: char, found: char },
    UnclosedOpenings  { expected: char, open_index: usize },
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct BracketError {
    pub index: usize,
    pub kind: BracketErrorKind,
}

fn opening_to_expected_closer(c: char) -> Option<char> {
    match c {
        '(' => Some(')'),
        '[' => Some(']'),
        '{' => Some('}'),
        _   => None,
    }
}

fn is_closing(c: char) -> bool {
    matches!(c, ')' | ']' | '}')
}

/// Validate that brackets in the input are properly matched and nested.
/// Ignores all non-bracket characters.
pub fn validate_brackets(s: &str) -> Result<(), BracketError> {
    let mut st: Stack<(char, usize)> = Stack::new(); // (expected_closer, open_index)
    for (i, ch) in s.char_indices() {
        if let Some(expected) = opening_to_expected_closer(ch) {
            st.push((expected, i));
        } else if is_closing(ch) {
            match st.pop() {
                None => {
                    return Err(BracketError {
                        index: i,
                        kind: BracketErrorKind::UnexpectedClosing { found: ch },
                    });
                }
                Some((expected, _open_idx)) => {
                    if ch != expected {
                        return Err(BracketError {
                            index: i,
                            kind: BracketErrorKind::MismatchedPair { expected, found: ch },
                        });
                    }
                }
            }
        }
    }
    if let Some((expected, open_idx)) = st.pop() {
        return Err(BracketError {
            index: open_idx,
            kind: BracketErrorKind::UnclosedOpenings { expected, open_index: open_idx },
        });
    }
    Ok(())
}