use crate::stack::Stack;
use std::collections::HashMap;

#[derive(Clone, Debug)]
pub struct Alphabet { pub open_to_close: HashMap<char, char> }

impl Alphabet {
    pub fn with_pairs(pairs: &[(char, char)]) -> Self {
        let mut m = HashMap::new();
        for &(o, c) in pairs { m.insert(o, c); }
        Self { open_to_close: m }
    }
    pub fn default_ascii() -> Self {
        Self::with_pairs(&[('(', ')'), ('[', ']'), ('{', '}')])
    }
    #[inline] pub fn is_opener(&self, ch: char) -> bool { self.open_to_close.contains_key(&ch) }
    #[inline] pub fn is_closer(&self, ch: char) -> bool { self.open_to_close.values().any(|&v| v == ch) }
    #[inline] pub fn expected_for(&self, opener: char) -> Option<char> { self.open_to_close.get(&opener).copied() }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum BracketErrorKind {
    UnexpectedClosing { found: char },
    MismatchedPair    { expected: char, found: char },
    UnclosedOpenings  { expected: char, open_index: usize },
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct BracketError { pub index: usize, pub kind: BracketErrorKind }

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ErrorMode { StopAtFirst, CollectAll }

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum UnclosedPolicy { LatestOpen, EarliestOpen }

#[derive(Debug, Clone)]
pub struct Options {
    pub alphabet: Alphabet,
    pub error_mode: ErrorMode,
    pub unclosed_policy: UnclosedPolicy,
}

impl Default for Options {
    fn default() -> Self {
        Self {
            alphabet: Alphabet::default_ascii(),
            error_mode: ErrorMode::StopAtFirst,
            unclosed_policy: UnclosedPolicy::LatestOpen,
        }
    }
}

/// Core engine over an indexed iterator (index, char).
pub fn validate_indexed_iter<I>(iter: I, opts: &Options) -> Result<(), Vec<BracketError>>
where
    I: IntoIterator<Item = (usize, char)>,
{
    let mut st: Stack<(char, usize)> = Stack::new(); // (expected_closer, open_idx)
    let mut errors: Vec<BracketError> = Vec::new();
    let alph = &opts.alphabet;

    for (i, ch) in iter {
        if alph.is_opener(ch) {
            let expected = alph.expected_for(ch).expect("alphabet inconsistent");
            st.push((expected, i));
        } else if alph.is_closer(ch) {
            match st.pop() {
                None => {
                    let e = BracketError { index: i, kind: BracketErrorKind::UnexpectedClosing { found: ch } };
                    if matches!(opts.error_mode, ErrorMode::StopAtFirst) { return Err(vec![e]); }
                    errors.push(e);
                }
                Some((expected, _open_idx)) => {
                    if ch != expected {
                        let e = BracketError { index: i, kind: BracketErrorKind::MismatchedPair { expected, found: ch } };
                        if matches!(opts.error_mode, ErrorMode::StopAtFirst) { return Err(vec![e]); }
                        errors.push(e);
                    }
                }
            }
        } else {
            // ignore
        }
    }

    if !st.is_empty() {
        match opts.unclosed_policy {
            UnclosedPolicy::LatestOpen => {
                if let Some((expected, open_idx)) = st.pop() {
                    let e = BracketError { index: open_idx, kind: BracketErrorKind::UnclosedOpenings { expected, open_index: open_idx } };
                    if matches!(opts.error_mode, ErrorMode::StopAtFirst) { return Err(vec![e]); }
                    errors.push(e);
                }
            }
            UnclosedPolicy::EarliestOpen => {
                let mut tmp: Vec<(char, usize)> = Vec::new();
                while let Some(x) = st.pop() { tmp.push(x); }
                if let Some(&(expected, open_idx)) = tmp.last() {
                    let e = BracketError { index: open_idx, kind: BracketErrorKind::UnclosedOpenings { expected, open_index: open_idx } };
                    if matches!(opts.error_mode, ErrorMode::StopAtFirst) { return Err(vec![e]); }
                    errors.push(e);
                }
            }
        }
    }

    if errors.is_empty() { Ok(()) } else { Err(errors) }
}

/// Original convenience API.
pub fn validate_brackets(s: &str) -> Result<(), BracketError> {
    match validate_with_options(s, &Options::default()) {
        Ok(()) => Ok(()),
        Err(mut errs) => Err(errs.remove(0)),
    }
}

/// Configurable API over &str (byte indices).
pub fn validate_with_options(s: &str, opts: &Options) -> Result<(), Vec<BracketError>> {
    let mut idx = 0usize;
    let iter = s.chars().map(move |ch| {
        let here = idx;
        idx += ch.len_utf8();
        (here, ch)
    });
    validate_indexed_iter(iter, opts)
}

/// Streaming API over chars (character positions as indices).
pub fn validate_iter<I>(iter: I, opts: &Options) -> Result<(), Vec<BracketError>>
where
    I: IntoIterator<Item = char>,
{
    let mut pos = 0usize;
    let indexed = iter.into_iter().map(|ch| {
        let i = pos;
        pos += 1;
        (i, ch)
    });
    validate_indexed_iter(indexed, opts)
}

/// Streaming API when indices are provided upstream.
pub fn validate_indexed<I>(iter: I, opts: &Options) -> Result<(), Vec<BracketError>>
where
    I: IntoIterator<Item = (usize, char)>,
{
    validate_indexed_iter(iter, opts)
}
