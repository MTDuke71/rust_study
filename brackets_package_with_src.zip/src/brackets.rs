use crate::stack::Stack;

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum BracketErrorKind {
    UnexpectedClosing { found: char },
    MismatchedPair    { expected: char, found: char },
    UnclosedOpenings  { expected: char, open_index: usize },
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct BracketError {
    pub index: usize,
    pub kind: BracketErrorKind,
}

fn opening_to_expected_closer(c: char) -> Option<char> {
    match c {
        '(' => Some(')'),
        '[' => Some(']'),
        '{' => Some('}'),
        _   => None,
    }
}

fn is_closing(c: char) -> bool {
    matches!(c, ')' | ']' | '}')
}

/// Validate brackets in a string. Ignores all non-bracket characters.
/// Returns Ok(()) if valid; otherwise returns a BracketError describing the first failure.
pub fn validate_brackets(s: &str) -> Result<(), BracketError> {
    // Stack holds (expected_closer, open_index)
    let mut st: Stack<(char, usize)> = Stack::new();

    for (i, ch) in s.char_indices() {
        if let Some(expected) = opening_to_expected_closer(ch) {
            st.push((expected, i));
        } else if is_closing(ch) {
            match st.pop() {
                None => {
                    return Err(BracketError {
                        index: i,
                        kind: BracketErrorKind::UnexpectedClosing { found: ch },
                    });
                }
                Some((expected, _open_idx)) => {
                    if ch != expected {
                        return Err(BracketError {
                            index: i,
                            kind: BracketErrorKind::MismatchedPair { expected, found: ch },
                        });
                    }
                }
            }
        } else {
            // ignore
        }
    }

    if let Some((expected, open_idx)) = st.pop() {
        return Err(BracketError {
            index: open_idx,
            kind: BracketErrorKind::UnclosedOpenings { expected, open_index: open_idx },
        });
    }

    Ok(())
}
