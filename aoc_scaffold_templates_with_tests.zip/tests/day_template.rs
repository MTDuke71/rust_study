
//! Copy this file to `tests/dayNN_examples.rs` and adjust day number & expectations.

use aoc_scaffold::prelude::*;

#[test]
fn dayNN_example() {
    // Put an example input in `inputs/dayNN_example.txt` and include it here:
    // let input = include_str!("../inputs/dayNN_example.txt");
    // let (p1, p2) = run_day(NN, input).unwrap();
    // assert_eq!(p1, "EXPECTED_P1");
    // assert_eq!(p2, "EXPECTED_P2");
    // This template intentionally does not compile until you fill it in for a real day.
    assert!(true);
}
